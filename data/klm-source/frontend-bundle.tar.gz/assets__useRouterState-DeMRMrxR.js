import{I as o,J as u,K as s}from"./index-C50fOIt6.js";function n(r){const e=o({warn:r?.router===void 0}),t=r?.router||e;return u(t.stores.__store,s(r,t))}export{n as u};
